#pragma comment(lib,"ws2_32.lib")
#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#define _WINSOCK_DEPRECATED_NO_WARNINGS

#pragma warning(disable : 4996)

using namespace std;

SOCKET Connection; // socket to hold connection 

void ClientThread()
{
	char buffer[256];
	while (true)
	{
		recv(Connection, buffer, sizeof(buffer), NULL);		//recv message from the server 
		cout << buffer << endl;																				
	}
}

int main()
{
	int password = 12345;

	cout << "Welcome to Habeshagram" << endl;
	cout << "Please enter a password ";
	cin >> password;

	while (password != 12345)
	{
		cout << "Wrong password" << endl;
		cout << "please enter the password ";
		cin >> password;
	}

	system("CLS");

	//creating socket
	WSAData wsaData;
	WORD D11Version = MAKEWORD(2, 1);

	if (WSAStartup(D11Version, &wsaData) != 0)				
	{
		MessageBoxA(NULL, "winsock startup failed", "Error", MB_OK | MB_ICONERROR);
		exit(1);
	}

	SOCKADDR_IN addr;  //address that will bind our listening socket 
	int addrlen = sizeof(addr); //length of the address required for accepting the call
	addr.sin_addr.s_addr = inet_addr("127.0.0.1"); //broadcast locally
	addr.sin_port = htons(1111);  //port
	addr.sin_family = AF_INET; //IPv4 socket

	Connection = socket(AF_INET, SOCK_STREAM, NULL);

	if (connect(Connection, (SOCKADDR*)&addr, sizeof(addr)) != 0)
	{
		MessageBoxA(NULL, "Failed to Connect", "Error", MB_OK | MB_ICONERROR);
		return 0;
	}

	cout << "Connected " << endl;

	CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)ClientThread, NULL, NULL, NULL);
	char buffer[256];	
	while (true)
	{
		cin.getline(buffer, sizeof(buffer));				//sends the message to the server 
		send(Connection, buffer, sizeof(buffer), NULL);
		Sleep(10);	
	}	

	system("pause");


	return 0;
}
