#pragma comment(lib,"ws2_32.lib")
#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>

#define _WINSOCK_DEPRECATED_NO_WARNINGS

#pragma warning(disable : 4996)

using namespace std;

SOCKET Connection;

void ClientThread()
{
	char buffer[256];
	while (true)
	{
		recv(Connection, buffer, sizeof(buffer), NULL);
		cout << buffer << endl;
	}
}

int main()
{
	int password = 12345;

	cout << "Welcome to Habeshagram" << endl;
	cout << "Please enter a password ";
	cin >> password;

	while (password != 12345)
	{
		cout << "Wrong password" << endl;
		cout << "please enter the password ";
		cin >> password;

	}

	system("CLS");

	WSAData wsaData;
	WORD D11Version = MAKEWORD(2, 1);

	if (WSAStartup(D11Version, &wsaData) != 0)
	{
		MessageBoxA(NULL, "winsock startup faild", "Error", MB_OK | MB_ICONERROR);
		exit(1);
	}

	SOCKADDR_IN addr;
	int addrlen = sizeof(addr);
	addr.sin_addr.s_addr = inet_addr("127.0.0.1");
	addr.sin_port = htons(1111);
	addr.sin_family = AF_INET;

	Connection = socket(AF_INET, SOCK_STREAM, NULL);

	if (connect(Connection, (SOCKADDR*)&addr, sizeof(addr)) != 0)
	{
		MessageBoxA(NULL, "Failed to Connect", "Error", MB_OK | MB_ICONERROR);
		return 0;
	}

	cout << "Connected" << endl;	
	CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)ClientThread, NULL, NULL, NULL);
	char buffer[256];	
	while (true)
	{
		cin.getline(buffer, sizeof(buffer));		
		send(Connection, buffer, sizeof(buffer), NULL);			
		Sleep(10);			
	}

	system("pause");



	return 0;
}
